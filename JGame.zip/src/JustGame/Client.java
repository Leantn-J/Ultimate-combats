package JustGame;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

public class Client {
	public Socket clientSocket;
	private DataInputStream dis;
	private DataOutputStream dos;
	
	public void connect() {
		try {
			clientSocket = new Socket("127.0.0.1", 10002);
			System.out.println("���� �Ϸ�");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public String dataRecv() {
		try {
			return dis.readUTF();
		} catch (Exception e) {
		}
		return null;
	}
	
	public void closeAll() {
		try {
			clientSocket.close();
			clientSocket.close();
			dis.close();
			dos.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void dataSend(String sendData) {
		try {
			dos.writeUTF(sendData);
		} catch (Exception e) {
		}
	}
	
	public void streamSetting() {
		try {
			dis = new DataInputStream(clientSocket.getInputStream());
			dos = new DataOutputStream(clientSocket.getOutputStream());
		} catch (Exception e) {
		}
	}

	public Client() {
		connect();
		streamSetting();
		dataSend("�ȳ��ϼ���");
		System.out.println(dataRecv());
	}
	
	public static void main(String[] args) {
		new Client();
	}
}