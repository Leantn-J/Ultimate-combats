package JustGame;

import java.awt.Color;

public class Function {
	DrawObject Do = new DrawObject();
	
	void move() {
		if(V.move[1] && V.canMove[1]) {
			V.px += V.speed / V.FPS;
			V.mpx += V.speed / V.FPS;
		}else if(V.move[3] && V.canMove[3]) {
			V.px -= V.speed / V.FPS;
			V.mpx -= V.speed / V.FPS;
		}if(V.move[0] && V.canMove[0]) {
			V.py -= V.speed / V.FPS;
			V.mpy -= V.speed / V.FPS;
		}else if(V.move[2] && V.canMove[2]) {
			V.py += V.speed / V.FPS;
			V.mpy += V.speed / V.FPS;
		}
	}
	
	void checkBlock(int bx, int by, int bw, int bh, int px, int py, int pw, int ph){
		if(bx <= px + pw && px <= bx + bw && py + ph >= by && py <= by + bh) {
			if(px + pw>= bx && py + ph > by && py < by + bh && px < bx) {
				V.canMove[1] = false;
				V.mpx = bx - pw + V.mx;
				V.px = bx - pw;
			}if(px <= bx + bw && py + ph > by && py < by + bh && px + pw > bx + bw) {
				V.canMove[3] = false;
				V.mpx = bx + bw + V.mx;
				V.px = bx + bw;
			}if(py + ph >= by && px < bx + bw && px + pw > bx && py < by) {
				V.canMove[2] = false;
				V.mpy = by - ph + V.my;
				V.py = by - ph;
			}if(py <= by + bh && px < bx + bw && px + pw > bx && py + ph > by + bh) {
				V.canMove[0] = false;
				V.mpy = by + bh + V.my;
				V.py = by + bh;
			}
		}
	}
	
	void cameraMove(int x, int y, int w, int h) {
		if(x + w / 2 > V.sw / 2 + w) {
			if(V.mx > -V.mw[V.nowMap] + V.sw) {
				V.mx -= V.speed / V.FPS;
				V.px -= V.speed / V.FPS;
			}
		}else if(x + w / 2 < V.sw / 2 - w) {
			if(V.mx < 0) {
				V.mx += V.speed / V.FPS;
				V.px += V.speed / V.FPS;
			}
		}if(y + h / 2 > V.sh / 2 + h) {
			if(V.my > -V.mh[V.nowMap] + V.sh) {
				V.my -= V.speed / V.FPS;
				V.py -= V.speed / V.FPS;
			}
		}else if(y + h / 2 < V.sh / 2 - h) {
			if(V.my < 0) {
				V.my += V.speed / V.FPS;
				V.py += V.speed / V.FPS;
			}
		}
		if(V.mx > 0)
			V.mx = 0;
		if(V.mx <  -V.mw[V.nowMap] + V.sw)
			V.mx =  -V.mw[V.nowMap] + V.sw;
		if(V.my > 0)
			V.my = 0;
		if(V.my < -V.mh[V.nowMap] + V.sh)
			V.my = -V.mh[V.nowMap] + V.sh;
	}
	
	void attack() {
		if(V.spaceClicked && V.skillTime == 0 && V.skilling == false) {
			V.speed = 120;
			if(V.pcolor[0] < 255) {
				Do.energy(V.px, V.py, V.pw, V.ph);
				V.pcolor[0]++;
				V.pg++;
				System.out.println(V.pg);
			}
		} else if(!V.spaceClicked && V.pg >= 20) {
			V.skilling = true;
			if(V.repeatCount == 0) {
				V.pcolor[0] = 0;
				V.skillStartTime = V.runningTime;
				Do.dummy = 0;
				Do.dummy = 20;
			} else {
				for(int i = 0; i < 4; i++)
					V.canMove[i] = false;
				Do.outEnergy(V.px, V.py, V.pw, V.ph);
				Do.sword(V.px + V.pw / 2, V.py + V.ph / 2, V.d);
			}
			V.skillTime = V.runningTime - V.skillStartTime;
			V.repeatCount++;
			
			if(V.skillTime / 1000 == V.pg / 50) {
				V.skilling = false;
				V.pg = 0;
				V.repeatCount = 0;
				V.speed = 300;
				V.skillTime = 0;
				V.swordh = 10;
				V.swordw = 10;
			}
		}
	}
	
	void dCheck() {
		for(int i = 0; i < 4; i++) {
			if(V.move[i] && !V.skilling)
				V.d = i;
		}
	}
}
