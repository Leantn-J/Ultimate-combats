package JustGame;

public class Clock {
	
	long startTime;
	long nowTime;
	long preTime;
	
	public void clock() {
		V.frameLate++;
		nowTime = System.currentTimeMillis();
		V.runningTime = (nowTime - startTime);
		
		if(V.runningTime / 1000 != preTime / 1000) {
			//System.out.println("frameLate : " + V.frameLate);
			V.frameLate = 0;
		}
		
		if(V.runningTime / 1000 != preTime / 1000) {
			//System.out.println("runningTime : " + V.runningTime / 10.0);
			preTime = V.runningTime;
		}
	}
}
