package JustGame;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JFrame;

public class Main extends JFrame implements Runnable, KeyListener, MouseMotionListener, MouseListener{

	Display d = new Display();
	Thread th;
	Map m = new Map();
	Function f = new Function();
	Init i = new Init();
	Clock c = new Clock();
	
	Main(){
		setSize(V.sw, V.sh);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		addKeyListener(this);
		addMouseListener(this);
		addMouseMotionListener(this);
		
		th = new Thread(this);
		th.start();
	}
	
	public void run() {
		c.startTime = System.currentTimeMillis();
		m.centralPark();
		while(true) {
			try {
				th.sleep(1000 / V.FPS);
				i.init();
				c.clock();
				repaint();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void paint(Graphics g) {
		if(V.buffg == null) {
			V.buffImage = createImage(V.sw, V.sh);
			V.buffg = V.buffImage.getGraphics();
		}
		d.display(V.buffg);
		g.drawImage(V.buffImage, 0, 0, null);
	}

	public void keyPressed(KeyEvent e) {
		System.out.println(e.getKeyCode());
		
		if(e.getKeyCode() == 39) {
			V.move[1] = true;
		}else if(e.getKeyCode() == 37) {
			V.move[3] = true;
		}if(e.getKeyCode() == 38) {
			V.move[0] = true;
		}else if(e.getKeyCode() == 40) {
			V.move[2] = true;
		}
		if(e.getKeyCode() == 32)
			if(!V.skilling)
				V.spaceClicked = true;
	}
	
	public void keyReleased(KeyEvent e) {
		if(e.getKeyCode() == 39) {
			V.move[1] = false;
		}else if(e.getKeyCode() == 37) {
			V.move[3] = false;
		}if(e.getKeyCode() == 38) {
			V.move[0] = false;
		}else if(e.getKeyCode() == 40) {
			V.move[2] = false;
		}
		if(e.getKeyCode() == 32)
			V.spaceClicked = false;
	}
	
	public void keyTyped(KeyEvent e) {
		
	}

	public void mouseDragged(MouseEvent e) {
		
	}

	public void mouseMoved(MouseEvent e) {
		V.mousex = e.getX();
		V.mousey = e.getY();
	}
	
	public void mouseClicked(MouseEvent e) {
		
	}

	public void mouseEntered(MouseEvent e) {
		
	}
	
	public void mouseExited(MouseEvent e) {
		
	}

	public void mousePressed(MouseEvent e) {
		
	}

	public void mouseReleased(MouseEvent e) {
		
	}
	
	public static void main(String[] args) {
		Main main = new Main();
	}
}
