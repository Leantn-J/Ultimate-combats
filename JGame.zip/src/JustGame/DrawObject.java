package JustGame;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class DrawObject {
	Random r = new Random();
	int a, x, y, bonus, power, power2, dummy = 20, dummy2 = 255;

	void blocks(Graphics g) {
		g.setColor(new Color(50, 50, 50));

		for (int j = 0; j < V.blockx.length; j++) {
			for (int i = 0; i < V.blockx[j].length; i++)
				g.fillRect(V.mx + V.blockx[j][i], V.my + V.blocky[j][i], V.bw, V.bh);
		}
	}

	void sword(int x, int y, int a) {
		V.buffg.setColor(new Color(255, 100, 100));
		bonus = V.pg / 80;
		if (bonus > 1) {
			power = V.sg * bonus;
			power2 = V.sg2 * bonus;
		} else {
			power = V.sg;
			power2 = V.sg2;
		}
		if (a == 0) {
			V.buffg.fillRect(x - V.swordw / 2, y - V.swordh - V.ph / 2, V.swordw, V.swordh);
			if (V.skillTime < V.sgt)
				V.swordw += power;
			else if (V.skillTime < V.sg2t)
				V.swordh += power2;
			if (V.skillTime >= V.sgt)
				shakeScreen();
		} else if (a == 1) {
			V.buffg.fillRect(x + V.pw / 2, y - V.swordh / 2, V.swordw, V.swordh);
			if (V.skillTime < V.sgt)
				V.swordh += power;
			else if (V.skillTime < V.sg2t)
				V.swordw += power2;
			if (V.skillTime >= V.sgt)
				shakeScreen();
		} else if (a == 2) {
			V.buffg.fillRect(x - V.swordw / 2, y + V.ph / 2, V.swordw, V.swordh);
			if (V.skillTime < V.sgt)
				V.swordw += power;
			else if (V.skillTime < V.sg2t)
				V.swordh += power2;
			if (V.skillTime >= V.sgt)
				shakeScreen();
		} else if (a == 3) {
			V.buffg.fillRect(x - V.pw / 2 - V.swordw, y - V.swordh / 2, V.swordw, V.swordh);
			if (V.skillTime < V.sgt)
				V.swordh += power;
			else if (V.skillTime < V.sg2t)
				V.swordw += power2;
			if (V.skillTime >= V.sgt)
				shakeScreen();
		}
	}

	void energy(int x, int y, int w, int h) {
		if(dummy <= 0) {
			dummy = 20;
		} else
			dummy -= V.pg / 10;
		V.buffg.setColor(new Color(255, 0, 0));
		V.buffg.fillOval(x - dummy, y - dummy, w + 2 * dummy, h + 2 * dummy);
	}
	
	void outEnergy(int x, int y, int w, int h) {
		if(dummy < V.pg) {
			dummy += V.pg / 5;
		}
		if(dummy2 - V.pg / 5 >= 0)
			dummy2 -= V.pg /5;
		else
			dummy2 = 0;
		V.buffg.setColor(new Color(255, 0, 0, dummy2));
		V.buffg.fillOval(x - dummy, y - dummy, w + 2 * dummy, h + 2 * dummy);
	}

	void shakeScreen() {
		a = r.nextInt() % 4;
		x = r.nextInt() % 5 * V.pg / 50;
		y = r.nextInt() % 5 * V.pg / 50;
		if (a == 0) {
			V.mx += x;
			V.my += y;
			V.px += x;
			V.py += y;
			V.mpx += x;
			V.mpy += y;
		} else if (a == 0) {
			V.mx -= x;
			V.my += y;
			V.px -= x;
			V.py += y;
			V.mpx -= x;
			V.mpy += y;
		} else if (a == 0) {
			V.mx += x;
			V.my -= y;
			V.px += x;
			V.py -= y;
			V.mpx += x;
			V.mpy -= y;
		} else {
			V.mx -= x;
			V.my -= y;
			V.px -= x;
			V.py -= y;
			V.mpx -= x;
			V.mpy -= y;
		}
	}
}
