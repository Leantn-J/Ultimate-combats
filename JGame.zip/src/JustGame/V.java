package JustGame;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

public class V {
	
	//===================================================================== ũ�� ���� �� ���
	
	static int sw = 1280, sh = 720;
	static int pw = 100, ph = 100;
	static int bulletw = 10, bulleth = 10;
	
	static int swordw = 10, swordh = 10;
	
	static int bw = 100, bh = 100;
	
	static int[] mw = {bw * 16}, mh = {bh * 24};
	
	//===================================================================== ��ġ ���� �� ���
	
	static int mousex, mousey;
	
	static int px = 200, py = 200;
	static int mpx = 100, mpy = 100;
	static int bulletx, bullety;
	
	static int mx = 0, my = 0;
	static int[] blueHomeBlocksx = {0, bw, bw * 2, bw * 3, bw * 4, bw * 4, bw * 4, bw * 4, bw * 4, 0, 0, 0, 0};
	static int[] blueHomeBlocksy = {0, 0, 0, 0, 0, bh, bh * 2, bh * 3, bh * 4, bh, bh * 2, bh * 3, bh * 4};
	static int[] redHomeBlocksx = {0, bw * 4, 0, bw * 4, 0, bw * 4, 0, bw * 4, 0, bw, bw * 2, bw * 3, bw * 4};
	static int[] redHomeBlocksy = {0, 0, bh, bh, bh * 2, bh * 2, bh * 3, bh * 3, bh * 4, bh * 4, bh * 4, bh * 4, bh * 4};
	static int[] centerBlocksx = {0, bw, bw * 2, bw * 3, bw * 6, bw * 7, bw * 8, bw * 9, 0, bw * 9, 0, bw * 9, 0, bw * 9, 0, bw * 9, 0, bw * 9, 0, bw * 9, 0, bw, bw * 2, bw * 3, bw * 6, bw * 7, bw * 8, bw * 9};
	static int[] centerBlocksy = {0, 0, 0, 0, 0, 0, 0, 0, bh, bh, bh * 2, bh * 2, bh * 3, bh * 3, bh * 6, bh * 6, bh * 7, bh * 7, bh * 8, bh * 8, bh * 9, bh * 9, bh * 9, bh * 9, bh * 9, bh * 9, bh * 9, bh * 9};
	
	static int[][] blockx = {blueHomeBlocksx, centerBlocksx, redHomeBlocksx};
	static int[][] blocky = {blueHomeBlocksy, centerBlocksy, redHomeBlocksy};
	
	//===================================================================== ��ġ ���� �� ���
	
	static int ps = 10;
	
	//===================================================================== ��Ÿ ��ġ ���� �� ���
	
	static long frameLate = 0;
	static long runningTime = 0;
	static int FPS = 30;
	static int keyCode;
	

	static long skillTime = 0;
	static long skillStartTime = 0;
	
	static int repeatCount = 0;
	
	static int speed = 300;
	
	static int nowMap = 0;
	
	static int d = 3;
	
	static int sg = 20;
	static int sg2 = 100;
	static int sgt = 250;
	static int sg2t = 500;
	static int pg = 0;
	
	static int[] pcolor = {0, 0, 0};
	
	//===================================================================== ���ڿ� ���� �� ���
	
	
	
	//===================================================================== �̹��� ���� �� ���
	
	static Image buffImage;
	
	//===================================================================== �� ���� ���� �� ���
	
	static boolean[] move = {false, false, false, false};
	static boolean[] canMove = {true, true, true, true};
	static boolean spaceClicked = false;
	static boolean skilling = false;
	
	//===================================================================== �Ҹ� ���� �� ���
	
	
	
	//===================================================================== ���� ���� �� ���

	static Color pc = new Color(V.pcolor[0], V.pcolor[1], V.pcolor[2]);
	
	//===================================================================== �۲� ���� �� ���
	
	static Font system = new Font("8-bit pusab", Font.PLAIN, 20);
	
	//===================================================================== ��Ÿ ���� �� ���
	
	static Graphics buffg;
	
	
}
