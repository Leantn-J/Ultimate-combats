package JustGame;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	private ServerSocket serverSocket;
	private Socket clientSocket;
	
	private DataInputStream dis;
	private DataOutputStream dos;
	
	public void  serverSetting() {
		try {
			serverSocket = new ServerSocket(10002);
			clientSocket = serverSocket.accept();
			System.out.println("Ŭ���̾�Ʈ ���� ����");
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void closeAll() {
		try {
			serverSocket.close();
			clientSocket.close();
			dis.close();
			dos.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void streamSetting() {
		try {
			dis = new DataInputStream(clientSocket.getInputStream());
			dos = new DataOutputStream(clientSocket.getOutputStream());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public String dataRecv() {
		try {
			return dis.readUTF();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
	
	public void dataSend(String sendData) {
		try {
			dos.writeUTF(sendData);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public Server() {
		serverSetting();
		streamSetting();
		System.out.println(dataRecv());
		dataSend("�߹޾Ҵ�");
		closeAll();
	}
	
	public static void main(String[] args) {
		new Server();
	}
}