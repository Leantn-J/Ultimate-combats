package JustGame;

import java.awt.Color;
import java.awt.Graphics;

public class Display {
	
	Function f = new Function();
	DrawObject Do = new DrawObject();
	Clock c = new Clock();
	
	void display(Graphics g) {
		g.setColor(new Color(255, 255, 255));
		g.fillRect(0, 0, 1280, 720);
		
		for(int i = 0; i < V.canMove.length; i++)
			V.canMove[i] = true;
		
		for(int j = 0; j < V.blockx.length; j++) {
			for(int i = 0; i < V.blockx[j].length; i++)
				f.checkBlock(V.mx + V.blockx[j][i], V.my + V.blocky[j][i], V.bw, V.bh, V.px, V.py, V.pw, V.ph);
		}

		Do.blocks(g);
		f.dCheck();
		f.attack();
		f.move();
		f.cameraMove(V.px, V.py, V.pw, V.ph);
		
		g.setColor(V.pc);
		g.fillOval(V.px, V.py, V.pw, V.ph);
	}
}
