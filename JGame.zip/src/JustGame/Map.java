package JustGame;

public class Map {
	void centralPark() {
		for(int i = 0; i < V.blockx[1].length; i++) {
			V.blockx[1][i] = V.blockx[1][i] + V.bw * 3;
			V.blocky[1][i] = V.blocky[1][i] + V.bh * 7;
		}
		for(int i = 0; i < V.blockx[2].length; i++) {
			V.blockx[2][i] = V.blockx[2][i] + V.bw * 11;
			V.blocky[2][i] = V.blocky[2][i] + V.bh * 19;
		}
	}
}
