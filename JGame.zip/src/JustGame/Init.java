package JustGame;

import java.awt.Color;

public class Init {
	void init() {
		V.pc = new Color(V.pcolor[0], V.pcolor[1], V.pcolor[2]);
	}
}
